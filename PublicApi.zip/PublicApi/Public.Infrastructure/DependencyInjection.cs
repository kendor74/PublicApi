﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Public.Application.Interface;
using Public.Infrastructure.Services;
using System.Security.Claims;
using System.Text;
namespace Public.Infrastructure
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            //var allowedOrigins = configuration.GetSection("AllowedOrigins").Get<string[]>();

            //services.Configure<InternalApis>(configuration.GetSection("InternalApis"));

            

            services.AddSingleton<IPortalServices, PortalService>();

            //services.AddCors(options =>
            //{
            //    options.AddPolicy("AllowedOrgins", policy =>
            //    {
            //        policy.WithOrigins(allowedOrigins!)
            //              .AllowAnyHeader()
            //              .AllowAnyMethod()
            //              .AllowCredentials();
            //    });
            //});


            return services;
        }
    }
}
