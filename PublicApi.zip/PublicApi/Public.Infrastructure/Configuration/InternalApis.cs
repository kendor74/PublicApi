﻿namespace Public.Infrastructure.Configuration
{
    public class InternalApis
    {
        public string LifePortal { get; set; }
        public string AuthHub { get; set; }
        //public Uri AML { get; set; }
    }
}
